//nao coloquei mais por falta de saber o que colocar//
public class mesa extends promocao{
    private String quantidadeCadeiras;
    private String b;
    private String c;
    private String d;

    @Override
    public String toString() {
        return "mesa{" + "quantidadeCadeiras=" + quantidadeCadeiras + ", b=" + b + ", c=" + c + ", d=" + d + '}';
    }

    public String getQuantidadeCadeiras() {
        return quantidadeCadeiras;
    }

    public String getB() {
        return b;
    }

    public String getC() {
        return c;
    }

    public String getD() {
        return d;
    }

    public void setQuantidadeCadeiras(String quantidadeCadeiras) {
        this.quantidadeCadeiras = quantidadeCadeiras;
    }

    public void setB(String b) {
        this.b = b;
    }

    public void setC(String c) {
        this.c = c;
    }

    public void setD(String d) {
        this.d = d;
    }
          }
