public class Cargo {
    private String nivel;
    private String nome;
    private String senha;
    private String confirmarSenha;

    @Override
    public String toString() {
        return "Cargo{" + "nivel=" + nivel + ", nome=" + nome + ", senha=" + senha + ", confirmarSenha=" + confirmarSenha + '}';
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setConfirmarSenha(String confirmarSenha) {
        this.confirmarSenha = confirmarSenha;
    }

    public String getNivel() {
        return nivel;
    }

    public String getNome() {
        return nome;
    }

    public String getSenha() {
        return senha;
    }

    public String getConfirmarSenha() {
        return confirmarSenha;
    }
}
