package br.com.grupo9.sistemadereservas.model.DAO;

import java.util.List;
import javax.persistence.TypedQuery;

import br.com.grupo9.sistemadereservas.model.PO.PromocaoPO;
import br.com.grupo9.sistemadereservas.model.Util.PersistenceUtil;

import javax.persistence.EntityManager;

public class PromocaoDAO {
	private EntityManager manager;
	
	public PromocaoDAO(){
        this.manager = PersistenceUtil.getEntityManager();
    }
	
	public PromocaoPO cadastrarPromocao(PromocaoPO promocaoPO){
		this.manager.getTransaction().begin();
		try{
			this.manager.persist(promocaoPO);
			this.manager.getTransaction().commit();
			return promocaoPO;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro tentar cadastrar o promocao. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public PromocaoPO getPromocaoByChave(PromocaoPO promocaoPO){
		try{
			StringBuilder query = new StringBuilder();
			query.append("SELECT u ")
				 .append("FROM PromocaoPO u ")
				 .append("WHERE u.chave = :chave");
			TypedQuery<PromocaoPO> typedQuery = this.manager.createQuery(query.toString(),PromocaoPO.class);
				typedQuery.setParameter("chave", promocaoPO.getChave());
				return (PromocaoPO) typedQuery.getSingleResult();
		}catch (Exception e) {
			System.out.println("\nOcorreu um erro ao capturar o promocao. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public List<PromocaoPO> getPromocaos(){
		try{
			StringBuilder query = new StringBuilder();
			query.append("SELECT u ")
				 .append("FROM PromocaoPO u ");
			TypedQuery<PromocaoPO> typedQuery = this.manager.createQuery(query.toString(),PromocaoPO.class);
				return (List<PromocaoPO>) typedQuery.getResultList();
		}catch (Exception e) {
			System.out.println("\nOcorreu um erro ao tentar capturar todos os promocaos. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public boolean altualizarPromocao(PromocaoPO promocaoPO){
		StringBuilder query = new StringBuilder();
		query.append("SELECT u ")
			 .append("FROM PromocaoPO u")
			 .append("WHERE u.chave = :chave");
		TypedQuery<PromocaoPO> typedQuery = this.manager.createQuery(query.toString(),PromocaoPO.class);
			typedQuery.setParameter("chave", promocaoPO.getChave());
			PromocaoPO promocao = (PromocaoPO)typedQuery.getSingleResult();
			this.manager.getTransaction().begin();
		try{
			if(promocao != null && promocao.getChave().equals(promocaoPO.getChave())){
				this.manager.merge(promocaoPO);
			}
			this.manager.getTransaction().commit();
			return true;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro ao tentar alterar o promocao. Causa:\n");
//			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deletarPromocao(PromocaoPO promocaoPO){
		StringBuilder query = new StringBuilder();
		query.append("SELECT u ")
			 .append("FROM PromocaoPO u ")
			 .append("WHERE u.chave = :chave");
		TypedQuery<PromocaoPO> typedQuery = this.manager.createQuery(query.toString(),PromocaoPO.class);
			typedQuery.setParameter("chave", promocaoPO.getChave());
			PromocaoPO promocao = (PromocaoPO)typedQuery.getSingleResult();
			this.manager.getTransaction().begin();
		try{
			if(promocao != null && promocao.getChave().equals(promocaoPO.getChave())){
				this.manager.remove(promocaoPO);
			}
			this.manager.getTransaction().commit();
			return true;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro ao tentar excluir o promocao. Causa:\n");
//			e.printStackTrace();
			return false;
		}
	}
}
