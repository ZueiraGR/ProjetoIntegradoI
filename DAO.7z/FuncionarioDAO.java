package br.com.grupo9.sistemadereservas.model.DAO;

import java.util.List;
import javax.persistence.TypedQuery;

import br.com.grupo9.sistemadereservas.model.PO.FuncionarioPO;
import br.com.grupo9.sistemadereservas.model.Util.PersistenceUtil;

import javax.persistence.EntityManager;

public class FuncionarioDAO {
	private EntityManager manager;
	
	public FuncionarioDAO(){
        this.manager = PersistenceUtil.getEntityManager();
    }
	
	public FuncionarioPO cadastrarFuncionario(FuncionarioPO funcionarioPO){
		this.manager.getTransaction().begin();
		try{
			this.manager.persist(funcionarioPO);
			this.manager.getTransaction().commit();
			return funcionarioPO;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro tentar cadastrar o funcionario. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public FuncionarioPO getFuncionarioByCpf(FuncionarioPO funcionarioPO){
		try{
			StringBuilder query = new StringBuilder();
			query.append("SELECT u ")
				 .append("FROM FuncionarioPO u ")
				 .append("WHERE u.cpf = :cpf");
			TypedQuery<FuncionarioPO> typedQuery = this.manager.createQuery(query.toString(),FuncionarioPO.class);
				typedQuery.setParameter("cpf", funcionarioPO.getCpf());
				return (FuncionarioPO) typedQuery.getSingleResult();
		}catch (Exception e) {
			System.out.println("\nOcorreu um erro ao capturar o funcionario. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public List<FuncionarioPO> getFuncionarios(){
		try{
			StringBuilder query = new StringBuilder();
			query.append("SELECT u ")
				 .append("FROM FuncionarioPO u ");
			TypedQuery<FuncionarioPO> typedQuery = this.manager.createQuery(query.toString(),FuncionarioPO.class);
				return (List<FuncionarioPO>) typedQuery.getResultList();
		}catch (Exception e) {
			System.out.println("\nOcorreu um erro ao tentar capturar todos os funcionarios. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public boolean altualizarFuncionario(FuncionarioPO funcionarioPO){
		StringBuilder query = new StringBuilder();
		query.append("SELECT u ")
			 .append("FROM FuncionarioPO u")
			 .append("WHERE u.cpf = :cpf");
		TypedQuery<FuncionarioPO> typedQuery = this.manager.createQuery(query.toString(),FuncionarioPO.class);
			typedQuery.setParameter("cpf", funcionarioPO.getCpf());
			FuncionarioPO funcionario = (FuncionarioPO)typedQuery.getSingleResult();
			this.manager.getTransaction().begin();
		try{
			if(funcionario != null && funcionario.getCpf().equals(funcionarioPO.getCpf())){
				this.manager.merge(funcionarioPO);
			}
			this.manager.getTransaction().commit();
			return true;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro ao tentar alterar o funcionario. Causa:\n");
//			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deletarFuncionario(FuncionarioPO funcionarioPO){
		StringBuilder query = new StringBuilder();
		query.append("SELECT u ")
			 .append("FROM FuncionarioPO u ")
			 .append("WHERE u.cpf = :cpf");
		TypedQuery<FuncionarioPO> typedQuery = this.manager.createQuery(query.toString(),FuncionarioPO.class);
			typedQuery.setParameter("cpf", funcionarioPO.getCpf());
			FuncionarioPO funcionario = (FuncionarioPO)typedQuery.getSingleResult();
			this.manager.getTransaction().begin();
		try{
			if(funcionario != null && funcionario.getCpf().equals(funcionarioPO.getCpf())){
				this.manager.remove(funcionarioPO);
			}
			this.manager.getTransaction().commit();
			return true;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro ao tentar excluir o funcionario. Causa:\n");
//			e.printStackTrace();
			return false;
		}
	}
}
