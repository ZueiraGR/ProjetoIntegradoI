package br.com.grupo9.sistemadereservas.model.DAO;

import java.util.List;
import javax.persistence.TypedQuery;

import br.com.grupo9.sistemadereservas.model.PO.ClientePO;
import br.com.grupo9.sistemadereservas.model.Util.PersistenceUtil;

import javax.persistence.EntityManager;

public class ClienteDAO {
	private EntityManager manager;
	
	public ClienteDAO(){
        this.manager = PersistenceUtil.getEntityManager();
    }
	
	public ClientePO cadastrarCliente(ClientePO clientePO){
		this.manager.getTransaction().begin();
		try{
			this.manager.persist(clientePO);
			this.manager.getTransaction().commit();
			return clientePO;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro tentar cadastrar o cliente. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public ClientePO getClienteByCpf(ClientePO clientePO){
		try{
			StringBuilder query = new StringBuilder();
			query.append("SELECT u ")
				 .append("FROM ClientePO u ")
				 .append("WHERE u.cpf = :cpf");
			TypedQuery<ClientePO> typedQuery = this.manager.createQuery(query.toString(),ClientePO.class);
				typedQuery.setParameter("cpf", clientePO.getCpf());
				return (ClientePO) typedQuery.getSingleResult();
		}catch (Exception e) {
			System.out.println("\nOcorreu um erro ao capturar o cliente. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public List<ClientePO> getClientes(){
		try{
			StringBuilder query = new StringBuilder();
			query.append("SELECT u ")
				 .append("FROM ClientePO u ");
			TypedQuery<ClientePO> typedQuery = this.manager.createQuery(query.toString(),ClientePO.class);
				return (List<ClientePO>) typedQuery.getResultList();
		}catch (Exception e) {
			System.out.println("\nOcorreu um erro ao tentar capturar todos os clientes. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public boolean altualizarCliente(ClientePO clientePO){
		StringBuilder query = new StringBuilder();
		query.append("SELECT u ")
			 .append("FROM ClientePO u")
			 .append("WHERE u.cpf = :cpf");
		TypedQuery<ClientePO> typedQuery = this.manager.createQuery(query.toString(),ClientePO.class);
			typedQuery.setParameter("cpf", clientePO.getCpf());
			ClientePO cliente = (ClientePO)typedQuery.getSingleResult();
			this.manager.getTransaction().begin();
		try{
			if(cliente != null && cliente.getCpf().equals(clientePO.getCpf())){
				this.manager.merge(clientePO);
			}
			this.manager.getTransaction().commit();
			return true;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro ao tentar alterar o cliente. Causa:\n");
//			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deletarCliente(ClientePO clientePO){
		StringBuilder query = new StringBuilder();
		query.append("SELECT u ")
			 .append("FROM ClientePO u ")
			 .append("WHERE u.cpf = :cpf");
		TypedQuery<ClientePO> typedQuery = this.manager.createQuery(query.toString(),ClientePO.class);
			typedQuery.setParameter("cpf", clientePO.getCpf());
			ClientePO cliente = (ClientePO)typedQuery.getSingleResult();
			this.manager.getTransaction().begin();
		try{
			if(cliente != null && cliente.getCpf().equals(clientePO.getCpf())){
				this.manager.remove(clientePO);
			}
			this.manager.getTransaction().commit();
			return true;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro ao tentar excluir o cliente. Causa:\n");
//			e.printStackTrace();
			return false;
		}
	}
}
