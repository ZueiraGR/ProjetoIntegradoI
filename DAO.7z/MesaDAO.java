package br.com.grupo9.sistemadereservas.model.DAO;

import java.util.List;
import javax.persistence.TypedQuery;

import br.com.grupo9.sistemadereservas.model.PO.MesaPO;
import br.com.grupo9.sistemadereservas.model.Util.PersistenceUtil;

import javax.persistence.EntityManager;

public class MesaDAO {
	private EntityManager manager;
	
	public MesaDAO(){
        this.manager = PersistenceUtil.getEntityManager();
    }
	
	public MesaPO cadastrarMesa(MesaPO mesaPO){
		this.manager.getTransaction().begin();
		try{
			this.manager.persist(mesaPO);
			this.manager.getTransaction().commit();
			return mesaPO;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro tentar cadastrar o mesa. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public MesaPO getMesaByIdentificacao(MesaPO mesaPO){
		try{
			StringBuilder query = new StringBuilder();
			query.append("SELECT u ")
				 .append("FROM MesaPO u ")
				 .append("WHERE u.identificacao = :identificacao");
			TypedQuery<MesaPO> typedQuery = this.manager.createQuery(query.toString(),MesaPO.class);
				typedQuery.setParameter("identificacao", mesaPO.getIdentificacao());
				return (MesaPO) typedQuery.getSingleResult();
		}catch (Exception e) {
			System.out.println("\nOcorreu um erro ao capturar o mesa. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public List<MesaPO> getMesas(){
		try{
			StringBuilder query = new StringBuilder();
			query.append("SELECT u ")
				 .append("FROM MesaPO u ");
			TypedQuery<MesaPO> typedQuery = this.manager.createQuery(query.toString(),MesaPO.class);
				return (List<MesaPO>) typedQuery.getResultList();
		}catch (Exception e) {
			System.out.println("\nOcorreu um erro ao tentar capturar todos os mesas. Causa:\n");
//			e.printStackTrace();
			return null;
		}
	}
	
	public boolean altualizarMesa(MesaPO mesaPO){
		StringBuilder query = new StringBuilder();
		query.append("SELECT u ")
			 .append("FROM MesaPO u")
			 .append("WHERE u.identificacao = :identificacao");
		TypedQuery<MesaPO> typedQuery = this.manager.createQuery(query.toString(),MesaPO.class);
			typedQuery.setParameter("identificacao", mesaPO.getIdentificacao());
			MesaPO mesa = (MesaPO)typedQuery.getSingleResult();
			this.manager.getTransaction().begin();
		try{
			if(mesa != null && mesa.getIdentificacao().equals(mesaPO.getIdentificacao())){
				this.manager.merge(mesaPO);
			}
			this.manager.getTransaction().commit();
			return true;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro ao tentar alterar o mesa. Causa:\n");
//			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deletarMesa(MesaPO mesaPO){
		StringBuilder query = new StringBuilder();
		query.append("SELECT u ")
			 .append("FROM MesaPO u ")
			 .append("WHERE u.identificacao = :identificacao");
		TypedQuery<MesaPO> typedQuery = this.manager.createQuery(query.toString(),MesaPO.class);
			typedQuery.setParameter("identificacao", mesaPO.getIdentificacao());
			MesaPO mesa = (MesaPO)typedQuery.getSingleResult();
			this.manager.getTransaction().begin();
		try{
			if(mesa != null && mesa.getIdentificacao().equals(mesaPO.getIdentificacao())){
				this.manager.remove(mesaPO);
			}
			this.manager.getTransaction().commit();
			return true;
		}catch (Exception e) {
			this.manager.getTransaction().rollback();
			System.out.println("\nOcorreu um erro ao tentar excluir o mesa. Causa:\n");
//			e.printStackTrace();
			return false;
		}
	}
}
